/**
 * Created by Andrés on 05-03-2017.
 */
// datos:
// 0 categoria
// 1 posicion
// 2 nombreclub
// 3 pg
// 4 pe
// 5 pp
// 6 pts
var datos = [];
var codCategorias = [];

$(document).ready(function () {
    obtenerListaCategorias();
    getDatosLiga();
    rellenarTabla(codCategorias[0]);
});

function getDatosLiga() {
     for(var i = 0; i<codCategorias.length;i++){
         var categoria = codCategorias[i];
        $.ajax({
            type: "POST",
            url: "../Logica/controlador-gestionar-partido.php",
            async: false,
            data: {
                tipo: "obtenerClubes",
                categoria: categoria
            }
        })
            .done(function (data) {
                var opts = $.parseJSON(data);
                $.each(opts, function (i, d) {
                    datos.push([categoria,
                        0,
                        d.nombreClubDeportivo,
                        getPartidosGanados(d.rutClubDeportivo,categoria),
                        getPartidosEmpatados(d.rutClubDeportivo,categoria),
                        getPartidosPerdidos(d.rutClubDeportivo,categoria),
                        (parseInt(getPartidosGanados(d.rutClubDeportivo,categoria))*3+
                        parseInt(getPartidosEmpatados(d.rutClubDeportivo,categoria)))
                    ])
                    ;
                    datos.sort(function (a,b) {
                        if (a[6] < b[6]) return  1;
                        if (a[6] > b[6]) return -1;
                        return 0;
                    });
                    //
                    // posiciones.push([i+1,categoria]);
                    // rutClubes.push([d.rutClubDeportivo,categoria]);
                    // nomClubes.push([d.nombreClubDeportivo,categoria]);
                    // PG.push(getPartidosGanados(d.rutClubDeportivo,categoria));
                    // PE.push(getPartidosEmpatados(d.rutClubDeportivo,categoria));
                    // PP.push(getPartidosPerdidos(d.rutClubDeportivo,categoria));
                });
            });
    }
    // printArray(datos);
}

function rellenarTabla(categoria){
    // $('#tbody1').empty();
    $('#tbody'+categoria).empty();
    var k = 1;
    for(var i = 0; i <datos.length;i++){
        if(datos[i][0][0][0][0][0]!=categoria)
            continue;
        datos[i][1]= k;
        k++;
        $('#tbody'+categoria).append(
            "<tr>"+
            "<td>" +datos[i][1]+ "</td>" +
            "<td>" +datos[i][2]+ "</td>" +
            "<td>" +datos[i][3][0][0]+ "</td>" +
            "<td>" +datos[i][4][0][0]+ "</td>" +
            "<td>" +datos[i][5][0][0]+ "</td>" +
            "<td>" +datos[i][6] + "</td>" +
            "</tr>"
        );


    }
}

function getIndex(array, target){
    for(var i = 0;i<array.length;i++){
        if(array[i].toString()===target.toString()){
            return i;
        }
    }
    return -1;
}

function printArray(array){
    for(var i = 0; i<array.length;i++){
        alert(array[i]);
        // alert("rutClub: "+array[i] + " PG: " + PG[i] + " PE: " + PE[i] + " PP: " + PP[i]);
    }
}


function obtenerListaCategorias() {
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-torneo.php",
        async: false,
        data: {
            tipo: "obtenerCategoriasQueSiEstenJugandoUnTorneoPorTipo",
            tipoTorneo: "liga"
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            var j = 0;
            $.each(opts, function (i, d) {
                codCategorias.push(d.codigoCategoria);
                // alert(j);
                if(j==0){
                    // href="#home"
                    $('#ulCategorias').append('<li class="active"> <a data-toggle="tab" href="#home" onclick="rellenarTabla('+ d.codigoCategoria +');" >' + d.nombreCategoria + '</a></li>');
                    $('#liga').append(
                        '<div id="home" class="tab-pane fade in active">' +
                            '<div class="table-responsive">' +
                                '<table class="table table-bordered table-hover">' +
                                    '<thread>' +
                                        '<tr>' +
                                             '<th>Posición</th>' +
                                             '<th>Club</th>' +
                                             '<th>PG</th>' +
                                             '<th>PE</th>' +
                                             '<th>PP</th>' +
                                             '<th>Pts</th>' +
                                          '</tr>' +
                                    '</thread>' +
                                        '<tbody id="tbody'+ d.codigoCategoria +'">' +
                                            // '<tr>' +
                                                // '<td> ' + posiciones[0] +' </td>' +
                                                // '<td> ' + nomClubes[0] +' </td>' +
                                                // '<td> ' + PG[0] +' </td>' +
                                                // '<td> ' + PE[0] +' </td>' +
                                                // '<td> ' + PP[0] +' </td>' +
                                                // '<td> ' + puntos[0] +' </td>' +
                                            // '</tr>' +
                                        '</tbody>' +
                                '</table>' +
                            '</div>' +
                        '</div>');
                }else{
                    $('#ulCategorias').append('<li> <a data-toggle="tab" href="#home" onclick="rellenarTabla('+ d.codigoCategoria +');" >' + d.nombreCategoria + '</a></li>');
                    // $('#liga').append(
                    //     '<div id="home'+ d.codigoCategoria +'" class="tab-pane fade in active">' +
                    //         '<div class="table-responsive">' +
                    //             '<table class="table table-bordered table-hover">' +
                    //                 '<thread>' +
                    //                     '<tr>' +
                    //                     '<th>Posición</th>' +
                    //                     '<th>Club</th>' +
                    //                     '<th>PG</th>' +
                    //                     '<th>PE</th>' +
                    //                     '<th>PP</th>' +
                    //                     '<th>Pts</th>' +
                    //                     '</tr>' +
                    //                 '</thread>' +
                    //                 '<tbody id="tbody'+ d.codigoCategoria +'">' +
                    //                 // '<tr>' +
                    //                 // '<td> ' + posiciones[0] +' </td>' +
                    //                 // '<td> ' + nomClubes[0] +' </td>' +
                    //                 // '<td> ' + PG[0] +' </td>' +
                    //                 // '<td> ' + PE[0] +' </td>' +
                    //                 // '<td> ' + PP[0] +' </td>' +
                    //                 // '<td> ' + puntos[0] +' </td>' +
                    //                 // '</tr>' +
                    //                 '</tbody>' +
                    //             '</table>' +
                    //         '</div>' +
                    //     '</div>');
                }
                j++;
            });
        });
}
function getPartidosGanados(club, categoria){
    var partidosGanados = [];
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-partido.php",
        async: false,
        data: {
            tipo: "obtenerPartidosGanadosPorClub",
            categoria: categoria,
            rutClub: club,
            tipoTorneo: 'liga'
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            $.each(opts, function (i, d) {
                var temp = [opts[0][0], categoria];
                partidosGanados.push(temp);
            });
        });
    return partidosGanados;
}
function getPartidosEmpatados(club, categoria){
    var partidosEmpatados = [];
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-partido.php",
        async: false,
        data: {
            tipo: "obtenerPartidosEmpatadosPorClub",
            categoria: categoria,
            rutClub: club,
            tipoTorneo: 'liga'
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            $.each(opts, function (i, d) {
                var temp = [d.partidosEmpatados, categoria];

                partidosEmpatados.push(temp);
            });
        });
    return partidosEmpatados;
}

function getPartidosPerdidos(club, categoria){
    var partidosPerdidos = [];
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-partido.php",
        async: false,
        data: {
            tipo: "obtenerPartidosPerdidosPorClub",
            categoria: categoria,
            rutClub: club,
            tipoTorneo: 'liga'
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            $.each(opts, function (i, d) {
                var temp = [d.partidosPerdidos, categoria];
                partidosPerdidos.push(temp);
            });
        });
    return partidosPerdidos;
}