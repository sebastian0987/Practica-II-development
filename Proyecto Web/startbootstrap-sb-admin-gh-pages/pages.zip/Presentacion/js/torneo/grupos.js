/**
 * Created by Andrés on 05-03-2017.
 */
// datos:
// 0 categoria
// 1 posicion
// 2 nombreclub
// 3 pg
// 4 pe
// 5 pp
// 6 pts
// 7 grupo

var datos = [];
var codCategorias = [];
var grupos = [];

$(document).ready(function () {
    obtenerListaCategorias();
    // getDatosClubes();
    for(var i = 0;i<codCategorias.length;i++){
        getGruposPorCategoria(codCategorias[i]);
    }
});
function getGruposPorCategoria(categoria){
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-torneo.php",
        async: false,
        data: {
            tipo: "obtenerGruposPorCategoria",
            categoria: categoria
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            var a = 0;
            var letras = ['Grupo A','Grupo B','Grupo C','Grupo D','Grupo E','Grupo F','Grupo G','Grupo H'];
            getDatosClubes(categoria);
            $.each(opts, function (i, d) {
                $('#ulGrupos'+categoria).append('<li class="active"> <a data-toggle="tab" href="#'+ d.codigoGrupo +'" onclick="rellenarTabla('+ categoria +','+ d.codigoGrupo +');" >' + letras[a] + '</a></li>');
                rellenarTabla(categoria,d.codigoGrupo);
                a++;
            });
        });
}
function getDatosClubes(categoria) {
        $.ajax({
            type: "POST",
            url: "../Logica/controlador-gestionar-partido.php",
            async: false,
            data: {
                tipo: "obtenerClubes",
                categoria: categoria
            }
        })
            .done(function (data) {
                var opts = $.parseJSON(data);
                $.each(opts, function (i, d) {
                    datos.push([categoria,
                        0,
                        d.nombreClubDeportivo,
                        getPartidosGanados(d.rutClubDeportivo,categoria),
                        getPartidosEmpatados(d.rutClubDeportivo,categoria),
                        getPartidosPerdidos(d.rutClubDeportivo,categoria),
                        (parseInt(getPartidosGanados(d.rutClubDeportivo,categoria))*3+
                        parseInt(getPartidosEmpatados(d.rutClubDeportivo,categoria))),
                        d.codigoGrupo
                    ]);
                    // alert($.inArray(d.codigoGrupo,grupos));
                    if($.inArray(d.codigoGrupo,grupos)==-1){
                        grupos.push(d.codigoGrupo);
                    }
                    datos.sort(function (a,b) {
                        if (a[6] < b[6]) return  1;
                        if (a[6] > b[6]) return -1;
                        return 0;
                    });
                    //
                    // posiciones.push([i+1,categoria]);
                    // rutClubes.push([d.rutClubDeportivo,categoria]);
                    // nomClubes.push([d.nombreClubDeportivo,categoria]);
                    // PG.push(getPartidosGanados(d.rutClubDeportivo,categoria));
                    // PE.push(getPartidosEmpatados(d.rutClubDeportivo,categoria));
                    // PP.push(getPartidosPerdidos(d.rutClubDeportivo,categoria));
                })

            });
    // printArray(datos);
}

function rellenarTabla(categoria, grupo){
    // por cada grupo de la categoria...
    $('#tbody'+categoria).empty();
    var k = 1;
    for(var i = 0; i <datos.length;i++){
        if(datos[i][7]==grupo && datos[i][0]==categoria){
            datos[i][1]= k;
            k++;
            $('#tbody'+categoria).append(
                "<tr>"+
                "<td>" +datos[i][1]+ "</td>" +
                "<td>" +datos[i][2]+ "</td>" +
                "<td>" +datos[i][3][0][0]+ "</td>" +
                "<td>" +datos[i][4][0][0]+ "</td>" +
                "<td>" +datos[i][5][0][0]+ "</td>" +
                "<td>" +datos[i][6] + "</td>" +
                "</tr>"
            );
        }

    }
}

function getIndex(array, target){
    for(var i = 0;i<array.length;i++){
        if(array[i].toString()===target.toString()){
            return i;
        }
    }
    return -1;
}

function printArray(array){
    for(var i = 0; i<array.length;i++){
        alert(array[i]);
        // alert("rutClub: "+array[i] + " PG: " + PG[i] + " PE: " + PE[i] + " PP: " + PP[i]);
    }
}


function obtenerListaCategorias() {
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-torneo.php",
        async: false,
        data: {
            tipo: "obtenerCategoriasQueSiEstenJugandoUnTorneoPorTipo",
            tipoTorneo: "grupos"
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            $.each(opts, function (i, d) {
                codCategorias.push(d.codigoCategoria);
                    $('#divCategorias').append(
                        '<div class="panel panel-green">' +
                            '<div class="panel-heading">' +
                                '<h3 class="panel-title">'+ d.nombreCategoria +'</h3>' +
                            '</div>' +
                            '<div class="panel-body">' +
                                '<ul class="nav nav-tabs" id="ulGrupos'+ d.codigoCategoria +'"  >' +
                                '</ul> '+
                                '<div id="tabs'+ d.codigoCategoria +'" class="tab-content"  >' +
                                '</div>' +
                                '<div class="tab-pane fade in active">' +
                                    '<div class="table-responsive">' +
                                        '<table class="table table-bordered table-hover">' +
                                        '<thread>' +
                                            '<tr>' +
                                            '<th>Posición</th>' +
                                            '<th>Club</th>'     +
                                            '<th>PG</th>'       +
                                            '<th>PE</th>'       +
                                            '<th>PP</th>'       +
                                            '<th>Pts</th>'      +
                                            '</tr>' +
                                        '</thread>' +
                                            '<tbody id="tbody'+ d.codigoCategoria +'"> ' +
                                            '</tbody>' +
                                       '</table>' +
                                    '</div>' +
                                '</div>' +
                            '</div>' +
                        '</div>'
                    );
                    // $('#liga').append(
                    //     '<div id="home'+ d.codigoCategoria +'" class="tab-pane fade in active">' +
                    //         '<div class="table-responsive">' +
                    //             '<table class="table table-bordered table-hover">' +
                    //                 '<thread>' +
                    //                     '<tr>' +
                    //                     '<th>Posición</th>' +
                    //                     '<th>Club</th>'     +
                    //                     '<th>PG</th>'       +
                    //                     '<th>PE</th>'       +
                    //                     '<th>PP</th>'       +
                    //                     '<th>Pts</th>'      +
                    //                     '</tr>' +
                    //                 '</thread>' +
                    //                 // '<tbody id="tbody'+ d.codigoCategoria +'">' +
                    //                 // '<tr>' +
                    //                 // '<td> ' + posiciones[0] +' </td>' +
                    //                 // '<td> ' + nomClubes[0] +' </td>' +
                    //                 // '<td> ' + PG[0] +' </td>' +
                    //                 // '<td> ' + PE[0] +' </td>' +
                    //                 // '<td> ' + PP[0] +' </td>' +
                    //                 // '<td> ' + puntos[0] +' </td>' +
                    //                 // '</tr>' +
                    //                 '</tbody>' +
                    //             '</table>' +
                    //         '</div>' +
                    //     '</div>');
            });

        });
}
function getPartidosGanados(club, categoria){
    var partidosGanados = [];
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-partido.php",
        async: false,
        data: {
            tipo: "obtenerPartidosGanadosPorClub",
            categoria: categoria,
            rutClub: club,
            tipoTorneo: 'grupos'
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            $.each(opts, function (i, d) {
                var temp = [opts[0][0], categoria];
                partidosGanados.push(temp);
            });
        });
    return partidosGanados;
}
function getPartidosEmpatados(club, categoria){
    var partidosEmpatados = [];
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-partido.php",
        async: false,
        data: {
            tipo: "obtenerPartidosEmpatadosPorClub",
            categoria: categoria,
            rutClub: club,
            tipoTorneo: 'grupos'
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            $.each(opts, function (i, d) {
                var temp = [d.partidosEmpatados, categoria];

                partidosEmpatados.push(temp);
            });
        });
    return partidosEmpatados;
}

function getPartidosPerdidos(club, categoria){
    var partidosPerdidos = [];
    $.ajax({
        type: "POST",
        url: "../Logica/controlador-gestionar-partido.php",
        async: false,
        data: {
            tipo: "obtenerPartidosPerdidosPorClub",
            categoria: categoria,
            rutClub: club,
            tipoTorneo: 'grupos'
        }
    })
        .done(function (data) {
            var opts = $.parseJSON(data);
            $.each(opts, function (i, d) {
                var temp = [d.partidosPerdidos, categoria];
                partidosPerdidos.push(temp);
            });
        });
    return partidosPerdidos;
}