<?php

?>
<html>
<head>
    <link href="css/torneo/crearTorneo.css" rel="stylesheet">
    <link href="css/torneo/funkycheckbox.css" rel="stylesheet">

    <script src='js/calendar/jquery.min.js'></script>
    <script src="js/torneo/elegirCategoria.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
</head>




<body>

<div class="container">
    <br>
    <br>
    <div id="divCategorias" class="row text-center">

<!--        <label disabled="" for="primera" class="btn btn-info">Primera División <input type="checkbox" disabled="" id="primera" class="badgebox"><span class="badge">&check;</span></label>-->

    </div>
</div>
<br>

</body>


</html>
