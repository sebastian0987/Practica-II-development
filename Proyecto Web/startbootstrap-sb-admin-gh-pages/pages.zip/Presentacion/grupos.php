<?php
/**
 * Created by PhpStorm.
 * User: Andrés
 * Date: 05-03-2017
 * Time: 15:28
 */
include "menuGlobal.php";
?>
<html>
<head>
<link href="css/index.css" rel="stylesheet">
<script src="js/torneo/grupos.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" />
</head>
<body>
<br>

<div id="divCategorias" class="row col-lg-6">

</div>
</body>
</html>
