<html>

<!--<body>-->
<!--<IMG src="image/acceso-denegado.jpg" style="margin: 0 auto; display: block">-->
<!--<div>-->
<!--    <a href="index.php" style="text-align: center">Regresar a la página principal</a>-->
<!--</div>-->
<!--</body>-->
<head>
    <!-- Website CSS style -->
    <link rel="stylesheet" type="text/css" href="css/login.css">

    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>

</head>
<body>
<div class="container">
    <div class="row main">
        <div class="main-login main-center">
            <form class="form-horizontal" method="post" action="#">
                <div class="form-group ">
                    <IMG src="image/acceso-denegado.jpg">
                </div>
                <div class="form-group ">
                    <h3 style="text-align: center">Debe iniciar sesión para acceder a la página deseada</h3>
                </div>
                <div class="login-register">
                    <a href="index.php">Regresar a la página principal</a>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
