<?php
/**
 * Created by PhpStorm.
 * User: Andrés
 * Date: 05-03-2017
 * Time: 15:28
 */
include "menuGlobal.php";
?>
<html>
<head>
<link href="css/index.css" rel="stylesheet">
<script src="js/torneo/liga.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" />
</head>
<body>

<div class="col-lg-6">
    <ul id="ulCategorias" class="nav nav-tabs">
    </ul>

    <div class="tab-content" id="liga">

    </div>
</div>
</body>
</html>
